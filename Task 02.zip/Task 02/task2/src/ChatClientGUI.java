import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;

public class ChatClientGUI {
    private JFrame frame;
    private JPanel messagePanel;
    private JTextField inputField;
    private PrintWriter out;
    private String clientName;

    public ChatClientGUI(String serverAddress, String clientName) {
        this.clientName = clientName;

        // Set up the networking
        try {
            Socket socket = new Socket(serverAddress, 12345);
            out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Set up the GUI
            frame = new JFrame(clientName);
            messagePanel = new JPanel();
            messagePanel.setLayout(new BoxLayout(messagePanel, BoxLayout.Y_AXIS));
            JScrollPane scrollPane = new JScrollPane(messagePanel);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            inputField = new JTextField(50);
            inputField.setMaximumSize(new Dimension(Integer.MAX_VALUE, inputField.getPreferredSize().height));

            frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
            frame.getContentPane().add(inputField, BorderLayout.SOUTH);

            frame.setSize(600, 400); // Set a larger size for the GUI
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);

            // Add action listener to the input field
            inputField.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    String message = inputField.getText();
                    if (!message.trim().isEmpty()) {
                        out.println(clientName + ": " + message);
                        inputField.setText("");
                    }
                }
            });

            // Start a new thread to listen for messages from the server
            new Thread(new Runnable() {
                public void run() {
                    try {
                        String message;
                        while ((message = in.readLine()) != null) {
                            addMessage(message);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Unable to connect to server", "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addMessage(String message) {
        boolean isSentByClient = message.startsWith(clientName);

        JPanel messageContainer = new JPanel();
        messageContainer.setLayout(new BoxLayout(messageContainer, BoxLayout.X_AXIS));
        if (isSentByClient) {
            messageContainer.add(Box.createHorizontalGlue());
        }

        JLabel messageLabel = new JLabel(message);
        messageLabel.setOpaque(true);
        messageLabel.setBackground(isSentByClient ? Color.CYAN : Color.LIGHT_GRAY);
        messageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        messageContainer.add(messageLabel);

        if (!isSentByClient) {
            messageContainer.add(Box.createHorizontalGlue());
        }

        messagePanel.add(messageContainer);
        messagePanel.revalidate();
        JScrollBar vertical = ((JScrollPane) messagePanel.getParent().getParent()).getVerticalScrollBar();
        vertical.setValue(vertical.getMaximum());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ChatClientGUI("localhost", "Client1");
                new ChatClientGUI("localhost", "Client2");
            }
        });
    }
}
